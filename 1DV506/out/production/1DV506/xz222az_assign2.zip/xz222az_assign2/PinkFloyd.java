package xz222az_assign2;

public class PinkFloyd {
    public static void main(String[] args) {
        int count = 0;

        while (count < 5){
            System.out.println("Pink Floyd rules!");
            count ++;
        }
    }


}
