package xz222az_assign1;

import java.util.Scanner;

public class Programming {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("What is the first programming language? ");
        String st1 = sc.nextLine();
        char ch1 = Character.toUpperCase(st1.charAt(0));

        System.out.print("And the second? ");
        String st2 = sc.nextLine();
        char ch2 = Character.toUpperCase(st2.charAt(0));

        System.out.print("And the third? ");
        String st3 = sc.nextLine();
        char ch3 = Character.toUpperCase(st3.charAt(0));

        sc.close();

        if (ch1 > ch2 && ch2 > ch3){
            System.out.println("Alphabetic order is " + st3 + " " + st2 + " " + st1);
        }
        else if (ch3 > ch2 && ch2 > ch1){
            System.out.println("Alphabetic order is " + st1 + " " + st2 + " " + st3);
        }
        else if (ch2 > ch1 && ch2 > ch3 && ch1 > ch3){
            System.out.println("Alphabetic order is " + st3 + " " + st1 + " " + st2);
        }
        else
            System.out.println("Alphabetic order is " + st1 + " " + st3 + " " + st2);

    }
}
