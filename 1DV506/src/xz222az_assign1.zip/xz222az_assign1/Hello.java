package xz222az_assign1;

public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello Word!");
    }
}
