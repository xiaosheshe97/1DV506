package xz222az_assign1;

public class ThreeLaws {
    public static void main(String[] args) {
        System.out.println("1. A robot may not injure a human being or, through inaction," +
                "allow a human being to come to harm.");
        System.out.println("2. A robot must obey the orders given it by human beings except" +
                " where such orders would conflict with the First Law.");
        System.out.println("3. A robot must protect its own existence as long as such protection" +
                " does not conflict with the First or Second Laws.");
    }
}
